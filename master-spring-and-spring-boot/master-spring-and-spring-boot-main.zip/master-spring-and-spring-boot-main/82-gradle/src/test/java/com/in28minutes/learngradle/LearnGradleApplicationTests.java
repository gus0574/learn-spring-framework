package com.in28minutes.learngradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
